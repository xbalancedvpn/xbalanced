package net.openvpn.openvpn;

public class SWIGTYPE_p_std__string {
    private long swigCPtr;

    protected SWIGTYPE_p_std__string(long cPtr, boolean futureUse) {
        this.swigCPtr = cPtr;
    }

    protected SWIGTYPE_p_std__string() {
        this.swigCPtr = 0;
    }

    protected static long getCPtr(SWIGTYPE_p_std__string obj) {
        return obj == null ? 0 : obj.swigCPtr;
    }
}
