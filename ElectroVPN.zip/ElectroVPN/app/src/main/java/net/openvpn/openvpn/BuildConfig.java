package net.openvpn.openvpn;

public final class BuildConfig {
    public static final boolean DEBUG = false;
}
