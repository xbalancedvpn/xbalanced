package net.openvpn.openvpn;

public class JellyBeanHackBase {
    protected static final boolean ENABLED = true;
}
