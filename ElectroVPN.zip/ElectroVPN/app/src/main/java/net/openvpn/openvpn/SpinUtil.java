package net.openvpn.openvpn;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import java.util.Arrays;
import android.widget.*;
import android.view.*;
import net.openvpn.openvpn.*;

public class SpinUtil {
    public static String[] get_spinner_list(Spinner spin) {
        ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
        if (aa == null) {
            return null;
        }
        int len = aa.getCount();
        String[] ret = new String[len];
        for (int i = 0; i < len; i++) {
            ret[i] = (String) aa.getItem(i);
        }
        return ret;
    }

    public static int get_spinner_count(Spinner spin) {
        ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
        if (aa == null) {
            return 0;
        }
        return aa.getCount();
    }

    public static String get_spinner_list_item(Spinner spin, int position) {
        ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
        if (aa == null) {
            return null;
        }
        return (String) aa.getItem(position);
    }

    public static String get_spinner_selected_item(Spinner spin) {
        return (String) spin.getSelectedItem();
    }

    public static void set_spinner_selected_item(Spinner spin, String selected_item) {
        if (selected_item != null) {
            String sel = get_spinner_selected_item(spin);
            if (sel == null || !selected_item.equals(sel)) {
                ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
                int len = aa.getCount();
                for (int pos = 0; pos < len; pos++) {
                    if (selected_item.equals(aa.getItem(pos))) {
                        spin.setSelection(pos);
                    }
                }
            }
        }
    }

	public static void show_spinner(Context context, Spinner spin, String[] content) {
        if (content != null) {
            String[] live_content = get_spinner_list(spin);
            if (live_content == null || !Arrays.equals(content, live_content)) {
                SpinnerAdapter aa = new RenzAdapter(context, content);
                spin.setAdapter(aa);
            }
        }
    }
	public static class RenzAdapter extends ArrayAdapter<String>
	{
		public RenzAdapter(Context context, String[] names)
		{
			super(context, R.layout.spinner_item, names);
		}

		@Override
		public String getItem(int position)
		{
			// TODO: Implement this method
			return super.getItem(position);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent)
		{
			// TODO: Implement this method
			return getCustomView(position, convertView, parent);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			// TODO: Implement this method
			return getCustomView(position, convertView, parent);
		}
		public View getCustomView(int position, View convertView, ViewGroup parent)
		{
			View v = LayoutInflater.from(getContext()).inflate(R.layout.spinner_item, parent, false);
			TextView tv = (TextView)v.findViewById(R.id.spinner_item_txt);
			ImageView iv = (ImageView)v.findViewById(R.id.spinner_item_image);

			String config = getItem(position);
			tv.setText(config);
			iv.setImageResource(android.R.drawable.ic_menu_view);
			if (config.contains("ca")) {
				iv.setImageResource(R.drawable.ca);
			} else if (config.contains("CA")) {
				iv.setImageResource(R.drawable.ca);
			} else if (config.contains("sg")) {
				iv.setImageResource(R.drawable.sg);
			} else if (config.contains("SG")) {
				iv.setImageResource(R.drawable.sg);
			} else if (config.contains("ph")) {
				iv.setImageResource(R.drawable.ph);
			} else if (config.contains("PH")) {
				iv.setImageResource(R.drawable.ph);
			} else if (config.contains("uk")) {
				iv.setImageResource(R.drawable.uk);
			} else if (config.contains("UK")) {
				iv.setImageResource(R.drawable.uk);
			} else if (config.contains("us")) {
				iv.setImageResource(R.drawable.us);
			} else if (config.contains("US")) {
				iv.setImageResource(R.drawable.us);
			} else if (config.contains("kr")) {
				iv.setImageResource(R.drawable.kr);
			} else if (config.contains("KR")) {
				iv.setImageResource(R.drawable.kr);
			} else if (config.contains("de")) {
				iv.setImageResource(R.drawable.de);
			} else if (config.contains("DE")) {
				iv.setImageResource(R.drawable.de);
			} else if (config.contains("nl")) {
				iv.setImageResource(R.drawable.nl);
			} else if (config.contains("NL")) {
				iv.setImageResource(R.drawable.nl);
			} else if (config.contains("jp")) {
				iv.setImageResource(R.drawable.jp);
			} else if (config.contains("JP")) {
				iv.setImageResource(R.drawable.jp);
			} else if (config.contains("in")) {
				iv.setImageResource(R.drawable.in);
			} else if (config.contains("IN")) {
				iv.setImageResource(R.drawable.in);
			} else {
				iv.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
			}
			// TODO: Implement this method
			return v;
		}

	}
}
