<?php die();
[routes]
GET /=Install->Get
POST /=Install->Set
?>